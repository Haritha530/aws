# AWS VPC Architecture with 2 Route Tables and NAT Gateway

This CloudFormation template sets up an AWS VPC with:

- 1 VPC
- 2 Public Subnets
- 2 Private Subnets
- 1 Internet Gateway
- 1 NAT Gateway
- 2 Route Tables (Public and Private)
- Route Table Associations

## Files

- `template.yaml`: Main CloudFormation template

## How to Deploy

1. Go to the AWS CloudFormation Console.
2. Create a new stack with `template.yaml`.
3. Use default parameters or customize CIDR blocks if needed.
4. Wait for deployment to complete.

## Architecture Diagram (optional)

You can create a visual diagram using draw.io or Lucidchart for easier understanding.

## License

MIT
